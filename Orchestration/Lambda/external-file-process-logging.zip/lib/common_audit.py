import json
import time
import boto3
import os
import pg8000
import unicodedata
import datetime

secret_session = boto3.client('secretsmanager')
redshift_client = boto3.client('redshift-data')
s3_client = boto3.client('s3')

# Read environment variables
secret_postgres = os.environ.get('secret_postgres')
postgres_config_audit_table = os.environ.get('postgres_config_audit_table')


def __archive_files(bucket_name, full_path, archive_folder, interface_id):
    source_bucket = bucket_name
    destination_bucket = bucket_name

    destination_folder = archive_folder
    interface_id = str(interface_id)

    # using count() to get count of "e"
    counter = full_path.count('/')

    # printing result
    print("Breaking the S3 path to check no of folders in file path : " + str(counter))

    folder_name = ""
    i = 3

    while i < counter:
        folder_name = folder_name + full_path.split('/')[i] + "/"
        i += 1

    # Convert the string to a list of characters
    string_list = list(folder_name)

    # Check if the string is not empty before replacing the last character
    if string_list:
        string_list[-1] = ""

    # Convert the list back to a string
    folder_final = ''.join(string_list)

    if folder_final:
        object_key = folder_final + "/" + full_path.split('/')[-1]
    else:
        object_key = full_path.split('/')[-1]

    source_folder = folder_final
    file_name = full_path.split('/')[-1]
    file_key = full_path.split('/')[-1]
    folder_name = folder_final

    print("source_folder --> " + source_folder)
    print("file_name --> " + file_name)
    print("file_key --> " + file_key)
    print("folder_name --> " + folder_final)

    if source_folder == 'processing':
        destination_file_key = "preprocessed_file_" + file_key
    else:
        destination_file_key = file_key

    print("source_bucket --> " + source_bucket)
    print("destination_bucket --> " + destination_bucket)
    print("source_folder --> " + source_folder)
    print("destination_folder --> " + destination_folder)
    print("file_key --> " + file_key)

    # Construct the source and destination object paths
    source_object_key = source_folder + "/" + file_key
    destination_object_key = destination_folder + "/" + interface_id + "/" + \
        destination_file_key + "_" + datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

    try:
        # Copy the file to the destination folder
        s3_client.copy_object(Bucket=destination_bucket,
                              CopySource={'Bucket': source_bucket,
                                          'Key': source_object_key},
                              Key=destination_object_key)

        # Delete the original file from the source folder
        s3_client.delete_object(Bucket=source_bucket, Key=source_object_key)

        return "s3://" + destination_bucket + "/" + destination_object_key

    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }


def _get_rs_cursor(secret_rs):
    secret_rs = secret_session.get_secret_value(SecretId=secret_rs)
    secret_rs_string = json.loads(secret_rs['SecretString'])
    rs_conn = pg8000.connect(
        host=secret_rs_string["host"],
        port=secret_rs_string["port"],
        database=secret_rs_string["database"],
        user=secret_rs_string["username"],
        password=secret_rs_string["password"],
        ssl_context=True
    )
    rs_cursor = rs_conn.cursor()
    rs_cursor.execute("set statement_timeout = 1200000")
    return rs_conn, rs_cursor


def _get_rds_cursor(secret_rds):
    secret_rds = secret_session.get_secret_value(SecretId=secret_rds)
    secret_rds_string = json.loads(secret_rds['SecretString'])
    rds_conn = pg8000.connect(
        host=secret_rds_string["host"],
        port=secret_rds_string["port"],
        # dbInstanceIdentifier=secret_rds_string["dbInstanceIdentifier"],
        user=secret_rds_string["username"],
        password=secret_rds_string["password"]
    )
    rds_cursor = rds_conn.cursor()
    rds_cursor.execute("set statement_timeout = 1200000")
    return rds_conn, rds_cursor


def _get_all_items(table, rds_cursor, schema_name, table_name):
    # fetch_query=f"select table_config_id,interface_name,COALESCE(schema_name,''),COALESCE(table_name,''),COALESCE(file_prefix,''),COALESCE(file_format,''),COALESCE(delimiter,''),COALESCE(header,''),COALESCE(trailer,''),COALESCE(column_names,''),COALESCE(Fixed_width_column_length,''),COALESCE(merge_query,''),COALESCE(split_files,''),COALESCE(split_prefix,''),interface_id from {table} where lower(schema_name) = '{schema_name}' and lower(table_name) = '{table_name}';"
    fetch_query = f"Select UDP_EXT_INTERFACE_CID ,QUERY from {table} where lower(TGT_SCHEMA_NAME) = '{schema_name}' and lower(TGT_TABLE_NAME) = '{table_name}';"
    rds_cursor.execute(fetch_query)

    all_items = rds_cursor.fetchall()
    if not all_items:
        print(
            f"No records found for file_type {table_name}. Exiting from _get_all_items function...")
        # You can raise an exception or exit the script here
        # For example:
        raise ValueError(
            f"No records found for file_type {table_name}. Exiting from _get_all_items function...")

    # for row in all_items:
    #    print(row)

    return all_items


def _redshift_api_call(secret_rs, query, statement_name):
    query = query
    secret_rs = secret_session.get_secret_value(SecretId=secret_rs)
    secret_rs_string = json.loads(secret_rs['SecretString'])

    host = secret_rs_string["host"]
    port = secret_rs_string["port"]
    database = secret_rs_string["database"]
    user = secret_rs_string["username"]
    password = secret_rs_string["password"]
    dbClusterIdentifier = secret_rs_string["dbClusterIdentifier"]

    response = redshift_client.execute_statement(
        ClusterIdentifier=dbClusterIdentifier, Database=database, Sql=query, DbUser=user, StatementName=statement_name, WithEvent=False)

    # retrieve the query ID and wait for the query to complete
    query_id = response['Id']

    return query_id


def _api_call_status_check(statementId):

    desc = redshift_client.describe_statement(Id=statementId)

    print(desc)

    status = desc["Status"]
    print("status is --> " + status)

    QueryString = desc["QueryString"]
    print("QueryString is --> " + QueryString)

    update_query = QueryString.split(';')[1]
    print("update_query --> " + update_query)

    update_statement = update_query.replace("'", "''")

    print("update_statement --> " + update_statement)

    # merge_query = QueryString.split(';')[2]
    # print("merge_query --> " + merge_query)

    # merge_statement = merge_query.replace("'","''")

    # print("merge_statement --> " + merge_statement)

    ResultRows = desc["ResultRows"]
    print("ResultRows is --> " + str(ResultRows))

    error_message = ''

    if status == "FAILED" or status == "ABORTED":
        print('SQL query failed:' + statementId + ": " + desc["Error"])
        error_msg = desc["Error"]
        print("error_msg is --> " + str(error_msg))
        error_message = statementId + "-->" + str(error_msg)

    created_at = ''
    updated_at = ''

    created_at = str(desc["CreatedAt"]).split('.')[0]

    print(created_at)

    updated_at = str(desc["UpdatedAt"]).split('.')[0]

    print(updated_at)

    return status, update_statement, error_message, created_at, updated_at

# this method sends the notification with subgroup failure notifcations failed at DB API calls or Lambda exceptions.


def notify(sns_topic_arn, subject, body):
    # part the subject and body and send email using sns arn
    subject = (
        "".join(ch for ch in subject if unicodedata.category(ch)[0] != "C"))[0:99]
    body = str(body)
    sns_client = boto3.client('sns')
    response = sns_client.publish(
        TargetArn=sns_topic_arn,
        Message=json.dumps({'default': json.dumps("{}"),
                            'sms': subject,
                            'email': body}),
        Subject=subject,
        MessageStructure='json'
    )
    return "message sent"
