import json
import time
import boto3
import os
import pg8000
import unicodedata
import datetime

from lib.common_audit import _get_rds_cursor
from lib.common_audit import _api_call_status_check
from lib.common_audit import __archive_files
from lib.common_audit import _get_rs_cursor
from lib.common_audit import _get_all_items
from lib.common_audit import _redshift_api_call
from lib.common_audit import notify

# ct stores current time
ct = datetime.datetime.now()
print("Execution Started at :-", ct)


secret_session = boto3.client('secretsmanager')
redshift_client = boto3.client('redshift-data')
s3_client = boto3.client('s3')

# Read environment variables
secret_postgres = os.environ.get('secret_postgres')
postgres_config_audit_table = os.environ.get('postgres_config_audit_table')
archive_folder = os.environ.get('archive_folder')
sns_topic_arn = os.environ.get('sns_topic_arn')
secret_redshift = os.environ.get('secret_redshift')
postgres_config_table = os.environ.get('postgres_config_table')
custom_error_msg = os.environ.get('custom_error_msg')
timezone = os.environ.get('timezone')

print(custom_error_msg)
print(timezone)


print("postgres_config_audit_table. --> " + str(postgres_config_audit_table))


def lambda_handler(event, context):
    try:
        print(event)

        # Retrieve event details
        statementId = event['detail']['statementId']
        statement_Name = event['detail']['statementName']

        interface_name = statement_Name.split('|')[0]
        schema_name = statement_Name.split('|')[1]
        table_name = statement_Name.split('|')[2]
        s3_path = statement_Name.split('|')[3]
        interface_id = statement_Name.split('|')[4]
        merge_final = statement_Name.split('|')[5]
        merge_query = statement_Name.split('|')[5].replace("'", "''")
        escape_charactor = statement_Name.split('|')[6]

        print(interface_name)
        print(schema_name)
        print(table_name)
        print(s3_path)
        print(interface_id)
        print(merge_final)
        print(merge_query)
        print(escape_charactor)
        print(statementId)

        # Connecting to RDS Postgres
        rds_conn, rds_cursor = _get_rds_cursor(secret_postgres)
        print("Connection to RDS through Secret Manager is success")

        # Connecting to REDSHIFT
        rs_conn, rs_cursor = _get_rs_cursor(secret_redshift)
        print("Connection to RS through Secret Manager is success")

        status, update_statement, error_message, created_at, updated_at = _api_call_status_check(statementId)

        if status == 'FINISHED':
            file_processed_status = 'Y'
        else:
            file_processed_status = 'N'

        print("File Processed_Status --> " + file_processed_status)

        error_final = error_message.replace("'", "''")

        # audit_query = f"insert into {postgres_config_audit_table}  (EXT_INTERFACE_CID  , TGT_SCHEMA_NAME , TGT_TABLE_NAME , FILE_PROCESS_STATUS , FILE_PROCESS_DATE , FILE_PRCSD_FLAG , MERGE_QUERY , ERROR_MSG , START_TIME , END_TIME , UPDATE_QUERY , ESCAPE_CHAR, CREATED_DATE, MODIFIED_DATE ) values ({interface_id},'{schema_name}','{table_name}','{s3_path}','{update_statement}','{merge_statement}','{status}','{error_final}','{created_at}','{updated_at}');"
        audit_query = f"insert into {postgres_config_audit_table}  (EXT_INTERFACE_CID  , TGT_SCHEMA_NAME , TGT_TABLE_NAME , FILE_PROCESS_STATUS , FILE_PROCESS_DATE , FILE_PRCSD_FLAG , MERGE_QUERY , ERROR_MSG , START_TIME , END_TIME , UPDATE_QUERY , ESCAPE_CHAR, CREATED_DATE, MODIFIED_DATE ) values ({interface_id},'{schema_name}','{table_name}','{status}',(current_timestamp at time zone '{timezone}'),'{file_processed_status}','{merge_query}','{error_final}','{created_at}' at time zone '{timezone}','{updated_at}' at time zone '{timezone}','{update_statement}','{escape_charactor}',current_timestamp at time zone '{timezone}',current_timestamp at time zone '{timezone}');"
        print(audit_query)

        rds_cursor.execute(audit_query)

        if status == 'FINISHED':
            
            bucket_name = s3_path.split('/')[2]
            print("bucket_name --> " + bucket_name)

            archived_file = __archive_files(bucket_name, s3_path, archive_folder, interface_id)
            print("File Archived to bucket --> " + bucket_name + " , folder --> " + archive_folder + " and file --> " + str(archived_file))            
            
            time.sleep(62)
            
            subject = "External File Processing Framework logging --> SUCCESS"
            body = f"Hello Team, \n\n External File Processing Framework logging success for file -->" + \
                str(s3_path)
            body = body + f"\n\n Please refer more details in postgres table --> " + \
                str(postgres_config_audit_table)
            #body = body + f"\n\n {custom_error_msg}"
            body = body + "\n\n Regards"
            body = body + "\n\n ------------------------------------------------------------------------------------------------------------  "
            notify(sns_topic_arn, subject, body)
            print("Execcution completed for file  - " + str(s3_path))

            statement = schema_name + "|" + table_name

            query_id = _redshift_api_call(
                secret_redshift, merge_final, statement)
            print("query_id -->" + str(query_id))

            # desc = redshift_client.describe_statement(Id=query_id)
            # print(desc)

        else:
            
            bucket_name = s3_path.split('/')[2]
            print("bucket_name --> " + bucket_name)
            
            interface_id = 'error'

            archived_file = __archive_files(bucket_name, s3_path, archive_folder, interface_id)
            print("File Archived to bucket --> " + bucket_name + " , folder --> " + archive_folder + " and file --> " + str(archived_file))                

            subject = "External File Processing Framework logging --> FAILED"
            body = f"Hello Team, \n\n External File Processing Framework logging Failed for file --> " + \
                str(s3_path)
            body = body + f"\n\n Exception: " + str(error_message)
            body = body + f"\n\n Please refer more details in postgres table --> " + \
                str(postgres_config_audit_table)
            body = body + "\n Please verify respective Lambda logs for more details."
            body = body + f"\n\n {custom_error_msg}"
            body = body + "\n\n Regards"
            body = body + "\n\n ------------------------------------------------------------------------------------------------------------  "
            notify(sns_topic_arn, subject, body)

        rds_conn.commit()
        rds_conn.close()

        # ct stores current time
        ct = datetime.datetime.now()
        print("Execution Completed at :-", ct)

    except Exception as e:
        error = ''
        error = "Error:" + str(e)
        
        print(error)

        # prepare subject and body for email notification when lambda code fails
        
        interface_id = 'error'
        
        archived_file = __archive_files(
            bucket_name, s3_path, archive_folder, interface_id)
        print("File Archived to bucket --> " + bucket_name + " , folder --> " +
              archive_folder + " and file --> " + str(archived_file))

        subject = "External File Processing Framework logging --> FAILED"
        body = f"Hello Team, \n\n External File Processing Framework logging Failed for file --> " + \
            str(s3_path)
        body = body + f"\n\n Exception: " + str(e)
        body = body + \
            f"\n\n Please take necessary actions and place the file again to process furthur or log it manually in table {postgres_config_audit_table} to not process the file again."
        body = body + "\n Please verify respective Lambda logs for more details."
        body = body + f"\n\n {custom_error_msg}"
        body = body + "\n\n Regards"
        body = body + "\n\n ------------------------------------------------------------------------------------------------------------  "
        notify(sns_topic_arn, subject, body)
        print("Exception - " + error)

        rds_conn.commit()
        rds_conn.close()

        # ct stores current time
        ct = datetime.datetime.now()
        print("Execution Failed at :-", ct)
