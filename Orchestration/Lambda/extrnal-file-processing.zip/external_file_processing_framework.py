import boto3
import pg8000
import os
import json
import zipfile
import sys
import unicodedata
import datetime


from lib.common_processing import _get_rs_cursor
from lib.common_processing import _get_rds_cursor
from lib.common_processing import _get_all_items
from lib.common_processing import _automated_command_creation
from lib.common_processing import _preprocessing
from lib.common_processing import _redshift_api_call
from lib.common_processing import _split_s3_file_by_first_two_chars
from lib.common_processing import __archive_files
from lib.common_processing import _record_count_check
from lib.common_processing import _extract_value_from_last_record
from lib.common_processing import _split_check_record_count_check
from lib.common_processing import _extract_bucketname_object_key
from lib.common_processing import _get_s3_object_size
from lib.common_processing import notify


# ct stores current time
ct = datetime.datetime.now()
print("Execution Started at :-", ct)

redshift_client = boto3.client('redshift-data')
secret_session = boto3.client('secretsmanager',region_name='us-east-1')
s3_client = boto3.client('s3')

print(boto3.__version__)

# Read environment variables
secret_postgres = os.environ.get('secret_postgres')
secret_redshift = os.environ.get('secret_redshift')
iam_role = os.environ.get('iam_role')
postgres_config_table = os.environ.get('postgres_config_table')
postgres_config_audit_table = os.environ.get('postgres_config_audit_table')
region = os.environ.get('region')
processing_folder = os.environ.get('processing_folder')
archive_folder = os.environ.get('archive_folder')
sns_topic_arn = os.environ.get('sns_topic_arn')
custom_error_msg = os.environ.get('custom_error_msg')
threshold_file_size_bytes = os.environ.get('threshold_file_size_bytes')
timezone = os.environ.get('timezone')



print(custom_error_msg)


def lambda_handler(event, context):
    try:
        print("\n\n------------------------------------------------------------------------\n\n")
        for record in event['Records']:
            ct = datetime.datetime.now()
            # Retrieve event details
            
            interface_id = ''
            
            event_name = record['eventName']
            bucket_name = record['s3']['bucket']['name']
            object_key = record['s3']['object']['key']

            print('Secretkey for Postgres --> ' + secret_postgres)
            print('Secretkey for Redshift --> ' + secret_redshift)
            print(secret_postgres)

            # Connecting to RDS Postgres
            rds_conn, rds_cursor = _get_rds_cursor(secret_postgres)
            print("Connection to RDS through Secret Manager is success")

            # Connecting to REDSHIFT
            rs_conn, rs_cursor = _get_rs_cursor(secret_redshift)
            print("Connection to RS through Secret Manager is success")

            print(f"S3 Event: {event_name}")
            print(f"Bucket: {bucket_name}")
            print(f"Object Key: {object_key}")

            # Print the full path of the object key

            original_file_path = f"s3://{bucket_name}/{object_key}"
            
            file_size = _get_s3_object_size(bucket_name, object_key)
            
            threshold_size_bytes=int(threshold_file_size_bytes)
            
            print("threshold_size_bytes --> " + str(threshold_file_size_bytes))
            
            
            # Compare with the threshold size
            if file_size >= threshold_size_bytes:
                print(f"The file size ({file_size} bytes) is greater than or equal to {threshold_size_bytes} bytes so moving ahead.")
            else:
                print(f"File size ({file_size} bytes) is less than {threshold_size_bytes} bytes. Failing it out .")
                raise ValueError(f"File size ({file_size} bytes) is less than {threshold_size_bytes} bytes. Failing and exiting out.")

            full_path = f"s3://{bucket_name}/{object_key}"
            print(f"Full path of the object: {full_path}")

            original_file_to_archive = full_path

            file_name_without_prefix = object_key.split('/')[-1]
            print("File_name without prefix --> " + file_name_without_prefix)

            file_format = file_name_without_prefix.split('.')[-1]
            print("file_format--> " + file_format)

            bucket_name, object_key, folder_name, file_name = _extract_bucketname_object_key(
                full_path)

            filename_without_format = file_name_without_prefix.split('.')[0]
            file_initials = filename_without_format.split('_')
            file_pattern = file_initials[-1].split('.')[0]
            file_type = file_pattern
            print("file_type--> " + file_type)

            original_file_type = file_type

            config_rds_items_check = _split_check_record_count_check(
                postgres_config_table, rds_cursor, original_file_type)
            print("Connection to config_rds_items_check to pull records is success")

            table_config_id = ''
            interface_name = ''
            schema_name = ''
            table_name = ''
            file_type = ''
            file_format = ''
            delimiter = ''
            header = ''
            trailer = ''
            column_names = ''
            fixed_width_column_length = ''
            split_files = ''
            split_prefix = ''
            file_record_count_prefix = ''

            for row in config_rds_items_check:
                table_config_id = row[0]
                interface_name = row[0]
                schema_name = row[1]
                table_name = row[2]
                file_type = row[3]
                file_format = row[4]
                delimiter = row[5]
                header = row[6]
                trailer = row[7]
                # column_names=row[9]
                # fixed_width_column_length=row[10]
                merge_query = row[8]
                split_files = row[9]
                split_prefix = row[10]
                interface_id = row[0]
                file_record_count_prefix = row[11].strip()
                escape_charactor = row[12].strip()
                file_type_suffix = row[13].strip()

                print("split_files --> " + str(split_files))
                print("split_prefix --> " + str(split_prefix))
                print("trailer --> " + str(trailer))
                print("file_record_count_prefix --> " +
                      str(file_record_count_prefix))
                print("file_format --> " + str(file_format))
                print("file_type_suffix --> " + str(file_type_suffix))
                
                file_format_from_file=original_file_path.split('.')[-1]
                
                print("file_format_from_file --> " + str(file_format_from_file))
                      
                if file_format_from_file == file_type_suffix:
                    print("File format of file --> " + original_file_path + "matching with config record for this file --> " + file_type_suffix + " so continuing the processing")
                else :
                    print("File format of file --> " + original_file_path + "not matching with config record for this file --> " + file_type_suffix + " so exiting the processing")
                    raise ValueError(f"File format of file -->  {original_file_path} not matching with config record for this file --> {file_type_suffix} so exiting the processing")
                  

                if trailer == 'Y':
                    if file_record_count_prefix:
                        print("Bucket Name ---> " + str(bucket_name))
                        print("object_key to split ---> " + str(object_key))

                        record_count = _record_count_check(
                            bucket_name, object_key, header)
                        print("record_count of file " +
                              original_file_path + "-->" + str(record_count))
                        record_count_file = _extract_value_from_last_record(
                            bucket_name, object_key, file_record_count_prefix, header)
                        print("record_count extracted from file " +
                              original_file_path + "-->" + str(record_count_file))

                        if record_count.strip() != record_count_file.strip():
                            print("Record count in file trailor " + record_count_file.strip() +
                                  " and total records counts of file " + record_count.strip() + " are not matching so exiting out....")
                            raise ValueError(f"Record count in file trailor {record_count_file.strip()} and total records counts of file {record_count.strip()} are not matching so exiting out....")
                        else:
                            if record_count_file == '0':
                                print(f"Record count in file trailor {record_count_file.strip()} so exiting out....")
                                raise ValueError(f"Record count in file trailor {record_count_file.strip()} so exiting out....")
                            else:
                                print("Record count in file trailor " + record_count_file.strip() +
                                  " and total records counts of file " + record_count.strip() + " are matching so processing furthur....")
                    else:
                        print(f"Failing for file {original_file_path} because trailer_pstn is not present in config table and trailer is present so exiting out")
                        raise ValueError(f"Failing for file {original_file_path} because trailer_pstn is not present in config table and trailer is present so exiting out")

                if split_files == 'Y':

                    if split_prefix:
                        print(
                            "split prefix is present so moving ahead --> " + str(split_prefix))
                    else:
                        print("If the split_prefix is empty, and the split_files is set to 'Y,' the configuration is incorrect. Please rectify it, and run accordingly so exiting out")
                        raise ValueError(f"If the split_prefix is empty, and the split_files is set to 'Y,' the configuration is incorrect. Please rectify it, and run accordingly so exiting out")

                    if trailer == 'Y':
                        final_path = _preprocessing(
                            full_path, processing_folder)
                    else:
                        final_path = full_path

                    destination_file_prefix = folder_name

                    bucket_name, object_key, folder_name, file_name = _extract_bucketname_object_key(
                        final_path)

                    source_bucket_name = bucket_name
                    destination_bucket_name = bucket_name
                    source_file_key = object_key

                    print("source_bucket_name --> " + source_bucket_name)
                    print("destination_bucket_name --> " +
                          destination_bucket_name)
                    print("source_file_key --> " + source_file_key)
                    print("destination_file_prefix --> " +
                          destination_file_prefix)

                    _split_s3_file_by_first_two_chars(
                        source_bucket_name, source_file_key, destination_bucket_name, destination_file_prefix, file_type, split_prefix)
                    print("Splitted files created at --> " +
                          destination_bucket_name + " --> " + destination_file_prefix)
                    archived_file = __archive_files(
                        source_bucket_name, full_path, archive_folder, interface_id)
                    print("File Archived to bucket --> " + source_bucket_name +
                          " , folder --> " + archive_folder + " and file --> " + str(archived_file))
                    print("Files Successfully splitted so exiting with exit code ")
                    print(
                        "\n\n------------------------------------------------------------------------\n\n")

                    return {

                        "statusCode": 200,
                        "body": "File Splitted successfully so exiting gracefully"
                    }
                    # sys.exit(0)

            config_rds_items = _get_all_items(
                postgres_config_table, rds_cursor, original_file_type)
            print("Connection to config_items to pull records is success")

            table_config_id = ''
            interface_name = ''
            schema_name = ''
            table_name = ''
            file_type = ''
            file_format = ''
            delimiter = ''
            header = ''
            trailer = ''
            column_names = ''
            fixed_width_column_length = ''
            split_files = ''
            split_prefix = ''
            file_record_count_prefix = ''
            escape_charactor = ''

            for row in config_rds_items:
                table_config_id = row[0]
                interface_name = row[0]
                schema_name = row[1]
                table_name = row[2]
                file_type = row[3]
                file_format = row[4]
                delimiter = row[5]
                header = row[6]
                trailer = row[7]
                column_names = row[8]
                fixed_width_column_length = row[9]
                merge_query = row[10]
                split_files = row[11]
                split_prefix = row[12]
                interface_id = row[0]
                file_record_count_prefix = row[13].strip()
                escape_charactor = row[14].strip()
                file_type_suffix = row[15].strip()

                print("table_config_id --> " + str(table_config_id))
                print("interface_name --> " + str(interface_name))
                print("schema_name --> " + schema_name)
                print("table_name --> " + table_name)
                print("file_prefix --> " + file_type)
                print("file_format --> " + file_format)
                print("delimiter --> " + delimiter)
                print("header --> " + header)
                print("trailer --> " + trailer)
                print("column_names --> " + str(column_names))
                print("fixed_width_column_length --> " +
                      str(fixed_width_column_length))
                print("merge_query --> " + str(merge_query))
                print("split_files --> " + str(split_files))
                print("split_prefix --> " + str(split_prefix))
                print("interface_id --> " + str(interface_id))
                print("file_record_count_prefix --> " +
                      str(file_record_count_prefix))
                print("escape_charactor --> " + str(escape_charactor))
                print("file_type_suffix --> " + str(file_type_suffix))

                if trailer == 'Y':
                    final_path = _preprocessing(full_path, processing_folder)
                    archived_file = __archive_files(
                        bucket_name, full_path, archive_folder, interface_id)
                    print("File Archived to bucket --> " + bucket_name + " , folder --> " +
                          archive_folder + " and file --> " + str(archived_file))
                else:
                    final_path = full_path

                full_path = str(final_path)

                copy_command = _automated_command_creation(
                    schema_name, table_name, file_format, delimiter, column_names, fixed_width_column_length, full_path, iam_role, region, header, escape_charactor)
                print("Command to run -> " + copy_command)

                file_name = full_path.split("/")[-1]
                print("file_name = " + file_name)

                update_query = "update " + schema_name + "." + table_name + " set file_name = '" + file_name + \
                    "' where file_name is null and trunc(target_transaction_timestamp) = CURRENT_DATE;"

                final_commands = copy_command + update_query #+ merge_query

                statement_name = str(interface_name) + '|' + schema_name + '|' + table_name + '|' + full_path + '|' + str(
                    interface_id) + '|' + merge_query + '|' + escape_charactor + '|external_file_frameowrk'
                print("statement_name --> " + statement_name)

                query_id = _redshift_api_call(
                    secret_redshift, final_commands, statement_name)
                print("query_id -->" + str(query_id))

                # desc = redshift_client.describe_statement(Id=query_id)
                # print(desc)

                # Close connections
                rds_conn.close()
                rs_conn.close()

                subject = "External File Processing Framework Submission --> SUCCESS"
                body = f"Hello Team, \n\n External File Processing Framework Submission success for file -->" + \
                    str(original_file_path)
                # body = body + f"\n\n Please refer more details in postgres table --> " + str(postgres_config_audit_table)
                #body = body + f"\n\n {custom_error_msg}"
                body = body + "\n\n Regards"
                body = body + "\n\n ------------------------------------------------------------------------------------------------------------  "
                notify(sns_topic_arn, subject, body)
                print("Execution completed for file  - " +
                      str(original_file_path))

                # ct stores current time
                ct = datetime.datetime.now()
                print("Execution Finished at :-", ct)
                print(
                    "\n\n------------------------------------------------------------------------\n\n")

    except Exception as e:
        
        error = "Error:" + str(e)
        print(error)


        if interface_id is not None and interface_id != "":
            interface_id = str(interface_id)
        else:
            interface_id = 'error'
        
        if interface_id == 'error':
            print("Interface is not present for skipping to audit it --> " + str(interface_id))
        else:
            
            print("Interface is present so auditing it --> " + str(interface_id))
        
            status = 'FAILED'
            file_processed_status = 'N'
            error_message = str(e)
            error_final = error_message.replace("'", "''")
            
            if table_name is not None and table_name != "":
                update_query = "update " + schema_name + "." + table_name + " set file_name = '" + file_name + \
                    "' where file_name is null and trunc(target_transaction_timestamp) = CURRENT_DATE;"
                    
                update_statement = update_query.replace("'", "''")
                merge_statement = merge_query.replace("'", "''")
            else:
                update_query = ''
                update_statement = ''
                merge_statement = ''
            
            # audit_query = f"insert into {postgres_config_audit_table}  (UDP_EXT_INTERFACE_CID  , TGT_SCHEMA_NAME , TGT_TABLE_NAME , FILE_PROCESS_STATUS , FILE_PROCESS_DATE , FILE_PRCSD_FLAG , MERGE_QUERY , ERROR_MSG , START_TIME , END_TIME , UPDATE_QUERY , ESCAPE_CHAR, CREATED_DATE, MODIFIED_DATE ) values ({interface_id},'{schema_name}','{table_name}','{s3_path}','{update_statement}','{merge_statement}','{status}','{error_final}','{created_at}','{updated_at}');"
            audit_query = f"insert into {postgres_config_audit_table}  (UDP_EXT_INTERFACE_CID  , TGT_SCHEMA_NAME , TGT_TABLE_NAME , FILE_PROCESS_STATUS , FILE_PROCESS_DATE , FILE_PRCSD_FLAG , MERGE_QUERY , ERROR_MSG , START_TIME , END_TIME , UPDATE_QUERY , ESCAPE_CHAR, CREATED_DATE, MODIFIED_DATE ) values ({interface_id},'{schema_name}','{table_name}','{status}',current_timestamp at time zone '{timezone}','{file_processed_status}','{merge_statement}','{error_final}','{ct}' at time zone '{timezone}',current_timestamp at time zone '{timezone}','{update_statement}','{escape_charactor}',current_timestamp at time zone '{timezone}',current_timestamp at time zone '{timezone}');"
            print(audit_query)
    
            rds_cursor.execute(audit_query)
            rds_conn.commit()
        
        interface_id = 'error'

        source_bucket_name = original_file_path.split('/')[2]
        print("bucket_name --> " + bucket_name)
        archived_file = __archive_files(
            source_bucket_name, original_file_path, archive_folder, interface_id)
        print("File Archived to bucket --> " + source_bucket_name +
              " , folder --> " + archive_folder + " and file --> " + str(archived_file))
            
        subject = "External File Processing Framework Submission --> FAILED"
        body = f"Hello Team, \n\n External File Processing Framework Submission Failed for file --> {original_file_path}"
        body = body + f"\n\n Exception: {str(e)}"
        body = body + "\n\n Please take necessary actions and place the file again to respective location to process it furthur."
        body = body + "\n\n Please verify respective Lambda logs for more details."
        body = body + f"\n\n {custom_error_msg}"
        body = body + "\n\n Regards"
        body = body + "\n\n ------------------------------------------------------------------------------------------------------------  "
        notify(sns_topic_arn, subject, body)
        print("Exception - " + error)

        # Close connections
        rds_conn.close()
        rs_conn.close()
                

        # ct stores current time
        ct = datetime.datetime.now()
        print("Execution Failed at :-", ct)
        print("\n\n------------------------------------------------------------------------\n\n")
