import boto3
import pg8000
import os
import json
import zipfile
import datetime
import unicodedata

redshift_client = boto3.client('redshift-data')
secret_session = boto3.client('secretsmanager')
s3_client = boto3.client('s3')


def _get_s3_object_size(bucket_name, object_key):
 
    # Get the object metadata
    response = s3_client.head_object(Bucket=bucket_name, Key=object_key)
    
    # Extract the content length (file size) from the response
    file_size = response['ContentLength']
    
    print("file_size from try -> " + str(file_size))
    
    return file_size


def _extract_bucketname_object_key(full_path):

    # using count() to get count of "e"
    counter = full_path.count('/')

    # printing result
    print("Breaking the S3 path to check no of folders in file path : " + str(counter))

    folder_name = ""
    i = 3

    while i < counter:
        folder_name = folder_name + full_path.split('/')[i] + "/"
        i += 1

    # Convert the string to a list of characters
    string_list = list(folder_name)

    # Check if the string is not empty before replacing the last character
    if string_list:
        string_list[-1] = ""

    # Convert the list back to a string
    folder_final = ''.join(string_list)

    if folder_final:
        object_key = folder_final + "/" + full_path.split('/')[-1]
    else:
        object_key = full_path.split('/')[-1]

    bucket_name = full_path.split('/')[2]
    file_name = full_path.split('/')[-1]
    object_key = object_key
    folder_name = folder_final

    print("bucket_name --> " + bucket_name)
    print("file_name --> " + file_name)
    print("object_key --> " + object_key)
    print("folder_name --> " + folder_final)

    return bucket_name, object_key, folder_name, file_name


def _get_rs_cursor(secret_rs):
    secret_rs = secret_session.get_secret_value(SecretId=secret_rs)
    secret_rs_string = json.loads(secret_rs['SecretString'])
    print(secret_rs_string)
    rs_conn = pg8000.connect(
        host=secret_rs_string["host"],
        port=secret_rs_string["port"],
        database=secret_rs_string["database"],
        user=secret_rs_string["username"],
        password=secret_rs_string["password"],
        ssl_context=True
    )
    print(rs_conn)
    rs_cursor = rs_conn.cursor()
    rs_cursor.execute("set statement_timeout = 1200000")
    return rs_conn, rs_cursor


def _get_rds_cursor(secret_rds):
    secret_rds = secret_session.get_secret_value(SecretId=secret_rds)
    secret_rds_string = json.loads(secret_rds['SecretString'])
    print(secret_rds_string)
    rds_conn = pg8000.connect(
        host=secret_rds_string["host"],
        port=secret_rds_string["port"],
        # dbInstanceIdentifier=secret_rds_string["dbInstanceIdentifier"],
        user=secret_rds_string["username"],
        password=secret_rds_string["password"]
    )
    print(rds_conn)
    rds_cursor = rds_conn.cursor()
    rds_cursor.execute("set statement_timeout = 1200000")
    return rds_conn, rds_cursor


def _record_count_check(bucket_name, object_key, header):

    # Get the S3 object
    s3_object = s3_client.get_object(Bucket=bucket_name, Key=object_key)

    # Read the content of the object
    content = s3_object['Body'].read().decode('utf-8')

    # Count the number of lines (assuming each line is a record)
    record_count = len(content.split('\n'))
    if header == 'Y':
        print("Record Count Check Final when header is present --> " +
              str(record_count-2))
        return str(record_count-2)
    else:
        print("Record Count Check Final when header is not present --> " +
              str(record_count-1))
        return str(record_count-1)


def _extract_value_from_last_record(bucket_name, object_key, position, header):
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
    content = response['Body'].read().decode('utf-8')

    # Split content into lines
    lines = content.split('\n')

    # Get the last line
    last_line = lines[-1]
    start_position = position.split(':')[0]
    end_position = position.split(':')[1]
    print("start_position --> " + str(start_position))
    print("end_position --> " + str(end_position))

    # Convert bytes to string if needed
    extracted_value = last_line[int(
        start_position)-1:int(end_position)-1].encode('utf-8')
    print("extracted_value --> " + str(extracted_value))

    return extracted_value.decode('utf-8')


def _split_s3_file_by_first_two_chars(source_bucket, source_file_key, destination_bucket, destination_file_prefix, file_type, split_prefix):

    print("S3 full path inside _split_s3_file_by_first_two_chars start --> " +
          str(source_bucket) + "/" + str(source_file_key))

    # Retrieve the source file from S3
    response = s3_client.get_object(Bucket=source_bucket, Key=source_file_key)
    content = response['Body'].read().decode('utf-8')

    # Split the content by lines
    records = content.split('\n')

    original_file_name_without_folder = source_file_key.split('/')[-1]
    original_file_name = original_file_name_without_folder.split('.')[0]
    original_file_ext = original_file_name_without_folder.split('.')[-1]

    print("original_file_name --> " + original_file_name)

    file_name_suffix = file_type.split('.')[0]
    file_name_prefix = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

    print("file_name_prefix --> " + file_name_prefix)
    print("file_name_suffix --> " + file_name_suffix)

    # Dictionary to store the records based on the first 2 characters
    records_dict = {}

    for record in records:
        # Skip empty lines
        if not record.strip():
            continue

        # Extract the first 2 characters

        if record[:2] in split_prefix:
            prefix = record[:2]
        else:
            continue

        # Add the record to the corresponding prefix key in the dictionary
        if prefix not in records_dict:
            records_dict[prefix] = []
        records_dict[prefix].append(record)

    # Write the records to separate files in the destination S3 bucket
    for prefix, records_list in records_dict.items():
        # Join the records back into a single string
        records_content = '\n'.join(records_list)

        # Write the records to the destination S3 bucket with a filename based on the prefix
        destination_file_key = f"{destination_file_prefix}/{original_file_name}-{file_name_prefix}_{file_name_suffix}-{prefix}.{original_file_ext}"
        s3_client.put_object(Bucket=destination_bucket,
                             Key=destination_file_key, Body=records_content)
        print("S3 full path inside _split_s3_file_by_first_two_chars end loop --> " +
              str(destination_bucket) + "/" + str(destination_file_key))

    print("Deletion of S3 file in _split_s3_file_by_first_two_chars  --> " +
          str(source_bucket) + "/" + str(source_file_key))
    s3_client.delete_object(Bucket=source_bucket, Key=source_file_key)


def _get_all_items(table, rds_cursor, file_type):

    fetch_query = f"select CAST(EXT_INTERFACE_CID AS VARCHAR), TGT_SCHEMA_NAME , TGT_TABLE_NAME ,FILE_PREFIX ,FILE_FORMAT,COALESCE(DELIMITER,''),HEADER_FLAG,TRAILER_FLAG ,string_agg (column_name, ',' order by column_order_sqnc asc ) as column_name,string_agg (column_name || ':' || column_width_fixed, ',' order by column_order_sqnc asc ) as column_width_fixed,QUERY,SPLIT_FILE_FLAG,COALESCE(SPLIT_PREFIX,''),COALESCE(TRAILER_PSTN,''),COALESCE(ESCAPE_CHAR,''),FILE_TYPE from {table} config , {table}_DTL  detail where config.ext_file_config_sid = detail.ext_file_config_sid and config.FILE_PREFIX like '%{file_type}.%' and config.OPRTNL_FLAG = 'A' and detail.OPRTNL_FLAG = 'A' group by EXT_INTERFACE_CID, TGT_SCHEMA_NAME, TGT_TABLE_NAME, FILE_PREFIX, FILE_FORMAT, DELIMITER, HEADER_FLAG, TRAILER_FLAG, QUERY, SPLIT_FILE_FLAG, SPLIT_PREFIX, TRAILER_PSTN, ESCAPE_CHAR,FILE_TYPE;"
    print("Fetch_Query --> " + str(fetch_query))

    rds_cursor.execute(fetch_query)
    all_items = rds_cursor.fetchall()
    # for row in all_items:
    #    print(row)

    if not all_items:
        print(
            f"No records found for file_type {file_type}. Exiting from _get_all_items function...")
        # You can raise an exception or exit the script here
        # For example:
        raise f"No records found for file_type {file_type}. Exiting from _get_all_items function..."

    print(all_items)
    return all_items


def _split_check_record_count_check(table, rds_cursor, file_type):

    fetch_query = f"select CAST(EXT_INTERFACE_CID AS VARCHAR), TGT_SCHEMA_NAME,TGT_TABLE_NAME,FILE_PREFIX,FILE_FORMAT,COALESCE(DELIMITER,''),HEADER_FLAG,TRAILER_FLAG,QUERY,SPLIT_FILE_FLAG,COALESCE(SPLIT_PREFIX,''),COALESCE(TRAILER_PSTN,''),COALESCE(ESCAPE_CHAR,''),FILE_TYPE from {table} config  where  config.FILE_PREFIX like '%{file_type}.%' and config.OPRTNL_FLAG = 'A';"
    print("Fetch_Query --> " + str(fetch_query))

    rds_cursor.execute(fetch_query)
    all_items = rds_cursor.fetchall()
    # for row in all_items:
    #    print(row)

    if not all_items:
        print(
            f"No records found for file_type {file_type}. Exiting from _split_check_record_count_check function...")
        # You can raise an exception or exit the script here
        # For example:
        raise ValueError(
            f"No records found for file_type {file_type}. Exiting from _split_check_record_count_check function..")

    print(all_items)
    return all_items


def _automated_command_creation(schema_name, table_name, file_format, delimiter, column_names, fixed_width_column_length, full_path, iam_role, region, header, escape_charactor):

    if escape_charactor:

        if file_format.lower() == 'fixed_width':
            if header == 'Y':
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  fixedwidth '" + \
                    fixed_width_column_length + "' REMOVEQUOTES  IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS   ACCEPTANYDATE region '" + region + "';"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  fixedwidth '" + \
                    fixed_width_column_length + \
                    "'  REMOVEQUOTES  IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + region + "';"

        elif file_format.lower() == 'gz' or file_format.lower() == 'bz2' or file_format.lower() == 'lzo':
            
            if file_format.lower() == 'gz':
                    file_format = 'gzip'
                    
            if file_format.lower() == 'bz2':
                    file_format = 'bzip2'
                    
            if file_format.lower() == 'lzo':
                    file_format = 'lzop'
                    
            if header == 'Y':
                
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + delimiter + \
                    "' REMOVEQUOTES IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + \
                    region + "'" + file_format.lower() + ";"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + \
                    delimiter + "' REMOVEQUOTES IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region '" + \
                    region + "'" + file_format.lower() + ";"

        else:
            if header == 'Y':
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + \
                    delimiter + "' REMOVEQUOTES IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + region + "';"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + \
                    delimiter + "' REMOVEQUOTES IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region '" + region + "';"

    else:

        if file_format.lower() == 'fixed_width':
            if header == 'Y':
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  fixedwidth '" + \
                    fixed_width_column_length + \
                    "' IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS   ACCEPTANYDATE region '" + region + "';"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  fixedwidth '" + \
                    fixed_width_column_length + \
                    "'  IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + region + "';"

        elif file_format.lower() == 'gz':
            
            if file_format.lower() == 'gz':
                    file_format = 'gzip'
            
            if header == 'Y':
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + delimiter + \
                    "' IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + \
                    region + "'" + file_format.lower() + ";"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + \
                    delimiter + "' IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region '" + \
                    region + "'" + file_format.lower() + ";"

        else:
            if header == 'Y':
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + "'  delimiter as '" + \
                    delimiter + "' IGNOREHEADER 1 IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region    '" + region + "';"
            else:
                copy_command = "copy " + schema_name + "." + table_name + "( " + column_names + " ) from '" + full_path + "' iam_role '" + iam_role + \
                    "'  delimiter as '" + delimiter + \
                    "' IGNOREBLANKLINES DATEFORMAT 'auto' TIMEFORMAT 'auto' ACCEPTINVCHARS ACCEPTANYDATE region '" + region + "';"

    return copy_command


def _preprocessing(full_path, processing_folder):

    # Print the full path of the object key
    print(f"Full path of the object: {full_path}")

    bucket_name = full_path.split('/')[2]
    file_name = full_path.split('/')[-1]

    # using count() to get count of "e"
    counter = full_path.count('/')

    # printing result
    print("Breaking the S3 path to check no of folders in file path : " + str(counter))

    folder_name = ""
    i = 3

    while i < counter:
        folder_name = folder_name + full_path.split('/')[i] + "/"
        i += 1

    # Convert the string to a list of characters
    string_list = list(folder_name)

    # Check if the string is not empty before replacing the last character
    if string_list:
        string_list[-1] = ""

    # Convert the list back to a string
    folder_final = ''.join(string_list)

    if folder_final:
        object_key = folder_final + "/" + full_path.split('/')[-1]
    else:
        object_key = full_path.split('/')[-1]

    bucket_name = full_path.split('/')[2]
    file_name = full_path.split('/')[-1]
    object_key = object_key
    folder_name = folder_final

    print("bucket_name --> " + bucket_name)
    print("file_name --> " + file_name)
    print("object_key --> " + object_key)
    print("folder_name --> " + folder_final)

    # file_format = file_name.split('.')[-1]
    # print("file_format--> " + file_format)

    # filename_without_format = file_name.split('.')[0]
    # file_initials = filename_without_format.split('_')
    # file_type = file_initials[0] + "_" + file_initials[1] + "_" + file_initials[2]

    # print("file_type--> " + file_type)

    print("original_file_name--> " + file_name)

    updated_path = f"s3://{bucket_name}/{processing_folder}/{file_name}"

    print("processing_file_path--> " + updated_path)

    try:
        # Download the S3 file
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        content = response['Body'].read().decode('utf-8')
        lines = content.split('\n')

        # Remove the trailer record (last line) from the content
        content_without_trailer = '\n'.join(lines[:-1])

        final_key = f"{processing_folder}/{file_name}"
        print("final key from _preprocessing --> " + final_key)

        # Upload the updated content back to S3
        s3_client.put_object(Bucket=bucket_name,
                             Key=final_key, Body=content_without_trailer)

    except Exception as e:
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'
        }
    print("Final_Updated_path from _preprocessing function --> " + str(updated_path))
    return updated_path


def _redshift_api_call(secret_rs, query, statement_name):
    query = query
    secret_rs = secret_session.get_secret_value(SecretId=secret_rs)
    secret_rs_string = json.loads(secret_rs['SecretString'])
    print("here1")
    print(secret_rs_string)
    host = secret_rs_string["host"]
    port = secret_rs_string["port"]
    database = secret_rs_string["database"]
    user = secret_rs_string["username"]
    password = secret_rs_string["password"]
    dbClusterIdentifier = secret_rs_string["dbClusterIdentifier"]
    print(host,port,database,user,password,dbClusterIdentifier)
    response = redshift_client.execute_statement(
        ClusterIdentifier=dbClusterIdentifier, Database=database, Sql=query, DbUser=user, StatementName=statement_name, WithEvent=True)

    # retrieve the query ID and wait for the query to complete
    query_id = response['Id']

    return query_id


def __archive_files(bucket_name, full_path, archive_folder, interface_id):
    source_bucket = bucket_name
    destination_bucket = bucket_name

    destination_folder = archive_folder
    interface_id = str(interface_id)

    # using count() to get count of "e"
    counter = full_path.count('/')

    # printing result
    print("Breaking the S3 path to check no of folders in file path : " + str(counter))

    folder_name = ""
    i = 3

    while i < counter:
        folder_name = folder_name + full_path.split('/')[i] + "/"
        i += 1

    # Convert the string to a list of characters
    string_list = list(folder_name)

    # Check if the string is not empty before replacing the last character
    if string_list:
        string_list[-1] = ""

    # Convert the list back to a string
    folder_final = ''.join(string_list)

    if folder_final:
        object_key = folder_final + "/" + full_path.split('/')[-1]
    else:
        object_key = full_path.split('/')[-1]

    source_folder = full_path.split('/')[3]
    file_name = full_path.split('/')[-1]
    file_key = object_key
    folder_name = folder_final

    print("source_folder --> " + source_folder)
    print("file_name --> " + file_name)
    print("file_key --> " + file_key)
    print("folder_name --> " + folder_final)

    if source_folder == 'processing':
        destination_file_key = "preprocessed_file_" + file_key.split('/')[-1]
    else:
        destination_file_key = file_key.split('/')[-1]

    print("source_bucket --> " + source_bucket)
    print("destination_bucket --> " + destination_bucket)
    print("source_folder --> " + source_folder)
    print("destination_folder --> " + destination_folder)
    print("file_key --> " + file_key)

    # Construct the source and destination object paths
    source_object_key = file_key
    destination_object_key = destination_folder + "/" + interface_id + "/" + \
        destination_file_key + "_" + datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

    try:
        # Copy the file to the destination folder
        s3_client.copy_object(Bucket=destination_bucket,
                              CopySource={'Bucket': source_bucket,
                                          'Key': source_object_key},
                              Key=destination_object_key)

        # Delete the original file from the source folder
        s3_client.delete_object(Bucket=source_bucket, Key=source_object_key)

        return "s3://" + destination_bucket + "/" + destination_object_key

    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }

# this method sends the notification with subgroup failure notifcations failed at DB API calls or Lambda exceptions.


def notify(sns_topic_arn, subject, body):
    # part the subject and body and send email using sns arn
    subject = (
        "".join(ch for ch in subject if unicodedata.category(ch)[0] != "C"))[0:99]
    body = str(body)
    sns_client = boto3.client('sns')
    response = sns_client.publish(
        TargetArn=sns_topic_arn,
        Message=json.dumps({'default': json.dumps("{}"),
                            'sms': subject,
                            'email': body}),
        Subject=subject,
        MessageStructure='json'
    )
    return "message sent"
